const config = {
    development: {
        GITHUB_CLIENT_ID: "<your client Id>",
        GITHUB_CLIENT_SECRET: "<your Client Secret>"
    }
}
module.exports = config