const config = {
    development: {
        GITHUB_CLIENT_ID: "19b05146904a7154f214",
        GITHUB_CLIENT_SECRET: "ede96bc7d74d8016f7e43c644fd0d9023d8f8ea3"
    }
}
module.exports = config